<?php
namespace Modules;

use System\BasicModule;

class Dashboard extends BasicModule {
    function install(){
    }

    function uninstall(){
    }
}